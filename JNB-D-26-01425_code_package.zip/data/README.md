# Input data specification

Do not commit individual-level analysis data unless its redistribution is explicitly permitted and the repository privacy plan has been approved.

## `nhanes_analysis_2017_2018.xlsx`

Required columns for the current script:

`SEQN`, `SDMVSTRA`, `SDMVPSU`, `WTDR2D`, `Cyanidin_mean`, `MASLD`, `Gender`, `Age`, `Race`, `Marital`, `EDUcation`, `PIR`, `Smoke`, `ALQ`, `DRTKCAL`, `DRTPROT`, `BMI`, `CAP`, `LSM`, `HSI`, `FLI`.

The reviewed local table also contained the laboratory and dietary variables used during derivation. The public repository should instead document how each field is reconstructed from the NHANES/FNDDS source files.

## `MASLD_cyanidin_gene_symbols.csv`

A UTF-8 CSV with one column named `SYMBOL`, one gene symbol per row. Do not include simulated fold changes. The original Word code generated random fold changes for a cnetplot; that visualization is intentionally excluded because it could be mistaken for observed expression data.

## `GSE202379_SeuratObject_AllCells.rds`

The reviewed E drive contains the downloaded Seurat object and two approximately 2.84 GB compressed copies. Obtain the public source from GEO and document its checksum rather than committing the multi-gigabyte object to GitHub.

## `h.all.v2023.2.Hs.symbols.gmt`

Hallmark gene sets used for pathway scoring. Record the MSigDB release and license/redistribution conditions. If redistribution is not permitted, provide official download instructions rather than committing the file.
